package com.inspur.pub.websocket;


import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;

import com.inspur.bas.service.notify.INotifyService;
import com.inspur.pub.token.CurrentUser;
import com.inspur.pub.token.JwtTokenUtil;

import net.sf.json.JSONObject;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.nio.ByteBuffer;
import java.security.Provider;

import org.apache.commons.codec.binary.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ConcurrentHashMap;


@ServerEndpoint(value="/websocket/threadsocket/{token}",configurator = GetHttpeSessionConfigurator.class)
// WebSocket实现类
@Component
public class WebSocket {

    private static JwtTokenUtil jwtTokenUtil;
    private static INotifyService notifyService;
    // 获得握手阶段的http请求
    @Autowired
    public void setJwtTokenUtil(JwtTokenUtil jwtTokenUtil) {
        WebSocket.jwtTokenUtil = jwtTokenUtil;
    }
    @Autowired
    public void setNotifyService(INotifyService notifyService) {
        WebSocket.notifyService = notifyService;
    }

    private static final Log log  = LogFactory.getLog(WebSocket.class);
    private Session session;

    private static ConcurrentHashMap<String,Session> sessionPool = new ConcurrentHashMap<>();

    private static ConcurrentHashMap<String,String> sessionIds = new ConcurrentHashMap<>();

    // 记录session和对应的类型
    private static ConcurrentHashMap<Session, Boolean> sessionPoolAndType = new ConcurrentHashMap<>();
    // 记录session和userId对应关系
    private static ConcurrentHashMap<Session, String> sessionAndUserId = new ConcurrentHashMap<Session, String>();

    private static ConcurrentHashMap<Session, Boolean> sessionAndSignFlag = new ConcurrentHashMap<Session, Boolean>();
    
    private static ConcurrentHashMap<Session, byte[]> sessionAndAppSign = new ConcurrentHashMap<Session, byte[]>();
    
    private static final long MAX_TIME_OUT = 60*60*1000;

    private static final String  HEART_BEAT = "HeartBeat";


    private String analysisToken(String token) throws Exception {
        CurrentUser user = jwtTokenUtil.checkToken(token);
        return user.getUid();
    }
    @OnOpen
    public void onOpen(Session session, @PathParam(value="token") String token,
                       EndpointConfig config) {
        Boolean isMobile = (Boolean) config.getUserProperties().get("isMobile");
        this.session = session;
        String userId = null;
        try {
            userId = analysisToken(token);
        } catch (Exception e) {
            log.error("【websocket消息】解析token异常,内容为:"+e);
            return;
        }
        log.info("[websocket]消息:成功建立起连接");
        // 设置websocket长连接时间
        session.setMaxIdleTimeout(MAX_TIME_OUT);
        sessionPoolAndType.put(session,isMobile);
        sessionAndUserId.put(session,userId);
        sessionAndSignFlag.put(session, false);


        if(isMobile) {
            // 手机端不给推送投票相关信息
            return;
        }
        // 记录websocket连接相关信息
//        sessionPool.put(userId,session);
//        sessionIds.put(session.getId(),userId);
        Integer number = notifyService.getNotReadNumber(userId);
        WebNotice webNotice = new WebNotice();
        if(0==number) {
            webNotice.setNumber(0);
        } else {
            Map<String,Object> resultMap = notifyService.getNotReadDetail(userId);
            webNotice.setNumber(number);
            webNotice.setTitle(MapUtils.getString(resultMap,"title"));
            webNotice.setCreateTime(MapUtils.getString(resultMap,"create_time"));
            webNotice.setType(MapUtils.getString(resultMap,"type"));
            webNotice.setAdditionalContent(MapUtils.getString(resultMap,"additional_content"));
        }
        String msg = JSON.toJSONString(webNotice);
        sendMessage(msg,userId);
        log.info("【websocket消息】用户id为"+userId+"的用户加入了连接，总数为："+sessionAndUserId.size());
    }

    // 连接关闭时触发，移除掉数据
    @OnClose
    public void OnClose() {
        log.info("【websocket消息】userId为："+sessionAndUserId.get(session)+"的用户，结束连接!");
//        sessionPool.remove(sessionIds.get(session.getId()));
//        sessionIds.remove(session.getId());
        sessionAndUserId.remove(session);
        sessionPoolAndType.remove(session);
        log.info("【websocket消息】连接总数为:"+sessionAndUserId.size());
    }

    // 收到信息时触发
    @OnMessage
    public void onMessage(String message) {
        log.info("【websocket消息】userId为"+sessionAndUserId.get(session)+"的用户发来消息，内容为:"+message);
        if(HEART_BEAT.equals(message)) {
            // 返回一个心跳
            WebNotice webNotice = new WebNotice();
            webNotice.setHeartBeat(true);
            try {
                session.getBasicRemote().sendText(JSON.toJSONString(webNotice));
            } catch (IOException e) {
                log.error("【websocket消息】心跳回应异常!");
            }
        }else {
        	JSONObject jsSign = JSONObject.fromObject(message);
        	sessionAndAppSign.put(session, Base64.decodeBase64(jsSign.getString("sign")));
        	sessionAndSignFlag.put(session, true);
        	log.info("sign内容为:"+Base64.decodeBase64(jsSign.getString("sign")));
        }
    }


    // 连接发生错误时触发
    @OnError
    public void onError(Session session,Throwable error) {
        log.error("【websocket消息】websocket连接发生异常："+error);
    }
    // 发送消息给前端的基础模块
    public static void sendMessage(String message,String userId) {
        // todo 更改相应的消息发送模块
//        Session s = sessionPool.get(userId);
        // 对所有的session都进行广播
        for(Session s: sessionAndUserId.keySet()) {
            // 所有的都给发送消息
            if(sessionAndUserId.get(s).equals(userId)) {
                try{
                    s.getBasicRemote().sendText(message);
                }catch (Exception e) {
                    log.error("【websocket消息】发送消息错误，内容为:"+e);
                    e.printStackTrace();
                }
            }
        }
    }


    // 广播消息到所有用户
    public static void sendAll(String msg) {
        for(Session s: sessionAndUserId.keySet()) {
            try {
                s.getBasicRemote().sendText(msg);
            } catch (IOException e) {
                log.info("【websocket消息】发送消息错误，内容为:"+e);
                e.printStackTrace();
            }
        }
    }


    // 批量给用户推送信息
    public static void customizeMessageByMap(Map<String,Object> map) {
        log.info("【websocket消息】正在推送消息");
        for(String userId:map.keySet()) {
            sendMessage((String) map.get(userId),userId);
        }
    }

    // 给手机用户发送消息
    public static void sendMessageToMobile(byte[] data,String curveName,Provider provider
    		,String algorithm,String userId) {
        for(Session s: sessionAndUserId.keySet()) {
            if(sessionAndUserId.get(s).equals(userId)
                && sessionPoolAndType.get(s)) {
                try{
            		Map<String, Object> resultMap = new HashMap<>();
                    resultMap.put("type", "sign");
                    resultMap.put("data", Base64.encodeBase64String(data));
                    resultMap.put("curveName",curveName);
                    resultMap.put("provider", Base64.encodeBase64String(toByteArray(provider)));
                    resultMap.put("algorithm",algorithm);
   
                	s.getBasicRemote().sendText(JSON.toJSONString(resultMap));
                	log.info("【websocket消息】成功发送消息给手机端用户");
                	checkCallBack(userId);
//                    ByteBuffer bf = ByteBuffer.wrap(message.getBytes());
//                    s.getBasicRemote().sendBinary(bf);
                    
                }catch(Exception e) {
                    log.info("【websocket消息】给手机端用户发送消息失败，原因为:"+e);
                }
            }
        }
    }
    
    
    public static byte[] toByteArray (Object obj) {      
        byte[] bytes = null;      
        ByteArrayOutputStream bos = new ByteArrayOutputStream();      
        try {        
            ObjectOutputStream oos = new ObjectOutputStream(bos);         
            oos.writeObject(obj);        
            oos.flush();         
            bytes = bos.toByteArray ();      
            oos.close();         
            bos.close();        
        } catch (IOException ex) {        
            ex.printStackTrace();   
        }      
        return bytes;    
    }  

    public static void checkCallBack(String userId) {
        long t1 = System.currentTimeMillis();
        while(true){
            long t2 = System.currentTimeMillis();
            if(t2-t1 > 10*1000){
                break;
            }else{
                if(getSignFlag(userId) == true) {
                	setSignFlag(userId,false);
                	break;
                }
            }
        }
        
    }
    
    public static byte[] getAppSign(String userId) {
    	Session tempSession = null;
        for(Session s: sessionAndUserId.keySet()) {
            if(sessionAndUserId.get(s).equals(userId)
                && sessionPoolAndType.get(s)) {
            	tempSession = s;
            }
        }
        return sessionAndAppSign.get(tempSession);
    }
    
    public static boolean getSignFlag(String userId) {
    	Session tempSession = null;
        for(Session s: sessionAndUserId.keySet()) {
            if(sessionAndUserId.get(s).equals(userId)
                && sessionPoolAndType.get(s)) {
            	tempSession = s;
            }
        }
    	return sessionAndSignFlag.get(tempSession);
    }
	public static void setSignFlag(String userId,boolean signFlag) {
    	Session tempSession = null;
        for(Session s: sessionAndUserId.keySet()) {
            if(sessionAndUserId.get(s).equals(userId)
                && sessionPoolAndType.get(s)) {
            	tempSession = s;
            }
        }
		sessionAndSignFlag.put(tempSession, signFlag);
		
	}
}
