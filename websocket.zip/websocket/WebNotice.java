package com.inspur.pub.websocket;

// websocket通知
public class WebNotice {
    // 未读消息数量
    private Integer number;
    // 标题
    private String title;
    // 时间
    private String createTime;
    // 通知类型
    private String type;
    // 附加信息
    private String additionalContent;

    // 是否为心跳,默认非心跳
    private Boolean heartBeat = false;

    public Boolean getHeartBeat() {
        return heartBeat;
    }

    public void setHeartBeat(Boolean heartBeat) {
        this.heartBeat = heartBeat;
    }

    public WebNotice() {

    }
    public WebNotice(Integer number) {
        this.number = number;
    }

    public WebNotice(Integer number, String title, String createTime, String type, String additionalContent,Boolean heartBeat) {
        this.number = number;
        this.title = title;
        this.createTime = createTime;
        this.type = type;
        this.additionalContent = additionalContent;
        this.heartBeat = heartBeat;
    }

    public Integer getNumber() {
        return number;
    }

    public void setNumber(Integer number) {
        this.number = number;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAdditionalContent() {
        return additionalContent;
    }

    public void setAdditionalContent(String additionalContent) {
        this.additionalContent = additionalContent;
    }
}
