package com.inspur.pub.websocket;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.log4j.helpers.SyslogQuietWriter;
import org.springframework.web.socket.server.standard.ServerEndpointExporter;

import javax.servlet.http.HttpSession;
import javax.websocket.HandshakeResponse;
import javax.websocket.server.HandshakeRequest;
import javax.websocket.server.ServerEndpointConfig;
import java.util.List;

// 判断是否为手机发来的连接
public class GetHttpeSessionConfigurator extends ServerEndpointConfig.Configurator {
    private final static Log log = LogFactory.getLog(GetHttpeSessionConfigurator.class);
    @Override
    public void modifyHandshake(ServerEndpointConfig sec, HandshakeRequest request, HandshakeResponse response) {
//        HttpSession httpSession = (HttpSession)request.getHttpSession();
        // 加入了httpSession对象
        // 通过request可以读出user-agent
//        System.out.println("request:"+request.getHeaders());
//        System.out.println("request:"+request.getHeaders().get("user-agent"));
        log.info("websocket建立握手连接，request的内容为:"+request.getHeaders());
        List<String> userAgentList = request.getHeaders().get("user-agent");
        Boolean isMobile = false;
        if(userAgentList == null || userAgentList.size() == 0) {
            log.info("【websocket消息】无法获得握手请求中的user-agent，将按照客户端处理");
            isMobile = true;
        } else {
            log.info("【websocket消息】连接的类型为:"+userAgentList.get(0));
            if(userAgentList.get(0).contains("Android") || userAgentList.get(0).contains("iPhone")) {
                // 说明是手机端
                isMobile = true;
            }
        }
        sec.getUserProperties().put("isMobile",isMobile);

//        sec.getUserProperties().put(HttpSession.class.getName(),httpSession);
    }
}
