package com.example.testsign.sign;

public class CryptoException extends BaseException {

    private static final long serialVersionUID = 1L;

    public CryptoException(String message, Exception parent) {
        super(message, parent);
    }

    public CryptoException(String message) {
        super(message);
    }

}
