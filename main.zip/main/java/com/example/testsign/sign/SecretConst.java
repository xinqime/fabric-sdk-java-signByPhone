package com.example.testsign.sign;

/**
 * @author zhang_lan@inspur.com
 * @description
 * @date 2019/9/10
 */
public class SecretConst {

    // 平台私钥加密时默认使用的秘钥
    public static final String DEFAULT_SECRET = "inpur123456a?";

}
