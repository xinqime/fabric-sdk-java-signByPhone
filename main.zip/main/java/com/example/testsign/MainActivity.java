package com.example.testsign;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.text.method.ScrollingMovementMethod;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.testsign.sign.CryptoException;
import com.example.testsign.sign.TestAppSign;
import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.koushikdutta.async.http.AsyncHttpClient;
import com.koushikdutta.async.http.AsyncHttpPost;
import com.koushikdutta.async.http.AsyncHttpResponse;
import com.koushikdutta.async.http.body.JSONObjectBody;

import org.apache.commons.codec.binary.Base64;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;
import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.Provider;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends Activity {
    //private static String token = "eyJ0eXBlIjoiSldUIiwiYWxnIjoiSFMyNTYifQ.eyJpc3MiOiJxdWFsaXR5Y2hhaW4iLCJhdWQiOiJ7XCJ0ZW5hbnRcIjp0cnVlLFwidHlwZVwiOlwidFwiLFwidWNvZGVcIjpcIlwiLFwidWlkXCI6XCIyMDIwMDIxODE0NTQxMDIyNTU4OFwiLFwidW5hbWVcIjpcIm5vdmVsXCJ9Iiwic3ViIjoib3QiLCJuYmYiOjE1ODQ1MjkwMjcsImlhdCI6MTU4NDUyOTAyNywiZXhwIjoxNTg0NTQzNDI3fQ.IVlJFDcE2InO2QNbyAd22XjQHdvdjDzEtmBBrn98K_g";
    private String token = null;
    private static String str = "sign";
    private  TextView textView;
    private boolean tokenIsShow = false;

    // 定时任务实现
    private Handler handler = new Handler();
    private String privateKey = "27E55391F932E26ED13E26DA18152D2060E223A3063FC049BEAFF6FC923B42094F6D7244B3E76709AE1500FB87F326676637765AFC58B48AAE0B46636A71781156BC603737EEE8BDC61BDED65A8695D167F03DF8E52B65E9633806F7359D35F713BFB80D4D99875CA226F5129964C456770EE31F00FDA3F8162C4C2CA0AE330131D6459D368CBF8B37A54AC143CEFA6303D22B2BEF942384952FC1072684C6176CFD0996C3640C45053FE0917C62DB16A5B75229FB759504EBB6F7DED599A9CABF7C8271E5E3DF189DFBEA5C396F916ABBF4A67F74C0B50B9D841C82BE62AC15F489BF12E7A7C170FE5A368284EB8F7AB47DB3B9F971A606304F9940D00BDE99C1E8D71F39A6D82DEC5FCE209C892E676A159780A5BD1E63F8C70E5B9188B192DE52D5CE04387B88ED765ECFCB0E8714";
    private byte[] data;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        {
            textView = findViewById(R.id.textView);

        }

        textView.setMovementMethod(ScrollingMovementMethod.getInstance());
        Button a = (Button)findViewById(R.id.button);
        a.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText phone = findViewById(R.id.editText);
                EditText pwd = findViewById(R.id.editText2);
                httpPost(phone.getText().toString(),md5(pwd.getText().toString()));
            }
        });

        Button b = (Button)findViewById(R.id.button2);
        b.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                Map<String,Object> postBody = new HashMap<>();

                postBody.put("wallet_secret", "");
                postBody.put("range", 100);
                postBody.put("type", "0");
                postBody.put("input","");
                postBody.put("description","test");
                postBody.put("organize_code",null);
                postBody.put("random_num","1");
                httpPost(postBody);
            }
        });



        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                //要执行的方法
                if(tokenIsShow == true){
                    textView.append("登录成功\n");
                    textView.append("token:"+token+"\n");
                    websocket();
                    tokenIsShow = false;
                }
                handler.postDelayed(this, 1000);
            }
        };
        handler.postDelayed(runnable, 1000);

    }


    public static String md5(String string) {
        if (TextUtils.isEmpty(string)) {
            return "";
        }
        MessageDigest md5 = null;
        try {
            md5 = MessageDigest.getInstance("MD5");
            byte[] bytes = md5.digest(string.getBytes());
            StringBuilder result = new StringBuilder();
            for (byte b : bytes) {
                String temp = Integer.toHexString(b & 0xff);
                if (temp.length() == 1) {
                    temp = "0" + temp;
                }
                result.append(temp);
            }
            return result.toString();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        return "";
    }



    private void websocket(){

        String url = "wss://dev.qualink.com/bas/websocket/threadsocket/" + token;
        try {
            WebSocketClient client = new WebSocketClient(new URI(url)){
                @Override
                public void onMessage(String message) {
                    Gson mGson = new Gson();
                    JsonObject obj = mGson.fromJson(message, JsonObject.class);
                    if(str.equals(obj.get("type").getAsString())){
                        textView.append("请求签名,弹出请求确认框\n");
                        textView.append("确认授权\n私钥获取成功\n");
                        byte[] data = Base64.decodeBase64(obj.get("data").getAsString());
                        String curveName = obj.get("curveName").getAsString();
                        byte[] providerByte = Base64.decodeBase64(obj.get("provider").getAsString());
                        Provider SECURITY_PROVIDER = (Provider) toObject(providerByte);
                        String DEFAULT_SIGNATURE_ALGORITHM = obj.get("algorithm").getAsString();
                        try {
                            TestAppSign testAppSign = new TestAppSign(privateKey);
                            textView.append(testAppSign.privateKey+"\n");
                            byte[] sign = testAppSign.ecdsaSignToBytes(data,curveName,SECURITY_PROVIDER,DEFAULT_SIGNATURE_ALGORITHM);

                            Map<String, Object> resultMap = new HashMap<>();
                            resultMap.put("type", "sign");
                            resultMap.put("sign", Base64.encodeBase64String(sign));

                            send(mGson.toJson(resultMap));
                            System.out.println(Arrays.toString(sign));
                        } catch (CryptoException e) {
                            textView.append(e+"\n");
                        }
                    }

                }

                @Override
                public void onOpen(ServerHandshake handshakedata) {
                    textView.append("websocket连接成功\n");
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {

                    textView.append("websocket连接关闭"+reason+"\n");
                    textView.append( "Connection closed by " + ( remote ? "remote peer" : "us" ) +"\n");
                }

                @Override
                public void onError(Exception ex) {
                    textView.append("websocket连接异常"+ex+"\n");
                }
            };
            client.connect();
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }
    }

    public Object toObject (byte[] bytes) {
        Object obj = null;
        try {
            ByteArrayInputStream bis = new ByteArrayInputStream(bytes);
            ObjectInputStream ois = new ObjectInputStream(bis);
            obj = ois.readObject();
            ois.close();
            bis.close();
        } catch (IOException ex) {
            ex.printStackTrace();
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
        return obj;
    }

    private void httpPost(String phone,String pwd) {
        String url = "https://dev.qualink.com/bas/login";
        Map<String,Object> postBody = new HashMap<>();
        postBody.put("phone", phone);
        postBody.put("auth_type", "01");
        postBody.put("pwd", pwd);

        JSONObjectBody writer = new JSONObjectBody(new JSONObject(postBody));
        try {
            AsyncHttpPost post = new AsyncHttpPost(url);
            post.setBody(writer);
            post.addHeader("Content-Type","application/json");

            AsyncHttpClient.getDefaultInstance().executeJSONObject(post,new AsyncHttpClient.JSONObjectCallback(){
                @Override
                public void onCompleted(Exception e, AsyncHttpResponse source, JSONObject result) {
                    try {
                        token = result.getString("data");
                        tokenIsShow = true;
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            });
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    private void httpPost(Map<String,Object> postBody) {
        String url = "https://dev.qualink.com/bas/random/create";

        JSONObjectBody writer = new JSONObjectBody(new JSONObject(postBody));
        try {
            AsyncHttpPost post = new AsyncHttpPost(url);
            post.setBody(writer);
            post.addHeader("Content-Type","application/json");
            post.addHeader("Authorization",token);

            AsyncHttpClient.getDefaultInstance().executeJSONObject(post,new AsyncHttpClient.JSONObjectCallback(){
                @Override
                public void onCompleted(Exception e, AsyncHttpResponse source, JSONObject result) {
                    try {
                        textView.append(result.toString());
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    }
                }
            });
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) throws URISyntaxException {};


}
