package com.example.testsign.httpUtil;

public class HttpUtil {

//    private void httpPost(String phone, String pwd) {
//        String url = "https://dev.qualink.com/bas/login";
//        Map<String, Object> postBody = new HashMap<>();
//        postBody.put("phone", phone);
//        postBody.put("auth_type", "01");
//        postBody.put("pwd", pwd);
//
//        JSONObjectBody writer = new JSONObjectBody(new JSONObject(postBody));
//        try {
//            AsyncHttpPost post = new AsyncHttpPost(url);
//            post.setBody(writer);
//            post.addHeader("Content-Type", "application/json");
//
//            AsyncHttpClient.getDefaultInstance().executeJSONObject(post, new AsyncHttpClient.JSONObjectCallback() {
//                @Override
//                public void onCompleted(Exception e, AsyncHttpResponse source, JSONObject result) {
//                    try {
//                        return result;
//                    } catch (Exception ex) {
//                        ex.printStackTrace();
//                    }
//                }
//            });
//        } catch (Exception ex) {
//            ex.printStackTrace();
//        }
//    }
}
